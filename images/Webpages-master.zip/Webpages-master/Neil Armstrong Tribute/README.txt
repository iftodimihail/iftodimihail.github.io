A Pen created at CodePen.io. You can find this one at https://codepen.io/iftodi_mihai/pen/LzwNJd.

 freecodecamp tribute page project of Neil Armstrong