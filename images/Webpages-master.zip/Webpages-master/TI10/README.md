Website that includes PHP and runs on Apache24 server

1st section - has a small form that prints a welcome message to whatever name is included in the input area

2nd section - gives info about server's ip, port and version and client's ip and port

3rd section - multiple choice test 


