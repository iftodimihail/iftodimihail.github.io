Upload files form using cookies (NOT PERFECT)

The files are uploaded through AJAX with a JSON file format.

The delete function not great.
