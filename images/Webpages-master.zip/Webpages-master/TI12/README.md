# Minimalistic online shopping website

Build on specific requirements and not very optimal.
