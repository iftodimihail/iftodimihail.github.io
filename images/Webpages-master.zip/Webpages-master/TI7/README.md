Simple news site without bootstrap
