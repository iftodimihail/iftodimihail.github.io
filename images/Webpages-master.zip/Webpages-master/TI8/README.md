A site composed of 4 sections:

-1st section contains general information about the browser, location, operating system, date and time;

-2nd sections contains a mini-game of lotto; it generates random numbers between 0-255 and then transforms them in hexazecimal so the input numbers most be in 2 digit hex([A-F0-9]); 

-3rd sections contains a canvas; you can select the stroke and fill colors and then click 2 times in different points of the canvas to draw a rectangle; it also has a "Clear canvas" button;

-4th sections contains a dynamic table editor; select the index and the color and then press one of the buttons to insert either a column or a row at that specific index with that color.

EDIT: used bootstrap
