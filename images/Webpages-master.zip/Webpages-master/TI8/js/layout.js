function columnsLayout(){
	document.getElementById("wrapper").className="columns";
}

function rowsLayout(){
	document.getElementById("wrapper").className="wrapper";
}

function cubicleLayout(){
	document.getElementById("wrapper").className="cubicle";
}
	