This site uses AJAX and has 4 sections: 

1st section - provides information about the 3 main sections of the website 

2nd section - includes a calculator which does simple math equations

3rd section - verifies if form inputs are valid using a JSON file

4th section - allows the search for a book in a library; the books will be stored in a XML file 

EDIT: the site runs on a localhost server and it was made through eclipse(Java EE)
