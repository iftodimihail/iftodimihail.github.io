# TRIVIA GAME 

Internet Technologies Homework

This site represents a trivia game made in JS.

The login/signup part is made in PHP.

# PLAY ZONE

You can play this game at: smarttrivia.000webhostapp.com

